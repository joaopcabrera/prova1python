from veiculo import Veiculo

class CarroPasseio(Veiculo):
    def __init__(self, marca, modelo, ano_fabricacao, chassi, cor, quilometragem, tipo_combustivel):
        super().__init__(marca, modelo, ano_fabricacao, chassi, cor, quilometragem)
        self._tipo_combustivel = tipo_combustivel

    def calcular_depreciacao(self, anos_uso, taxa_extra):
        depreciacao = anos_uso*taxa_extra
        print(f"Depreciação: Carro com {anos_uso} anos de uso tem depreciação estimada em R${depreciacao:.2f}")
        return depreciacao

    def exibir_informacoes(self, detalhado=False):
        super().exibir_informacoes(detalhado)
        if detalhado:
            print(f"Combustível: {self._tipo_combustivel}")
