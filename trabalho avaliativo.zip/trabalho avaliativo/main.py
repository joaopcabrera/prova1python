from carro_passeio import CarroPasseio
from caminhao_carga import CaminhaoCarga

carro = CarroPasseio("Chevrolet", "Camaro", 2020, "1234", "Branco", 45000, 4, "Gasolina")
carro.exibir_informacoes(detalhado=False)
carro.exibir_informacoes(detalhado=True)
carro.registrar_manutencao("Troca de óleo", 250)
carro.calcular_depreciacao(5, 1200)

print("\n" + "-"*50 + "\n")

caminhao = CaminhaoCarga("Volksvagem", "Creta", 2018, "5678", "Preto", 150000, 25.5, 4)
caminhao.exibir_informacoes(detalhado=False)
caminhao.exibir_informacoes(detalhado=True)
caminhao.registrar_manutencao("Revisão geral", 3000)
caminhao.registrar_vistoria("Vistoria anual", multa=500)
